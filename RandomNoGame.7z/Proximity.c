#include<stdio.h>

int main()
{
    int RandVariable = 5;
    int UserVariable = 0;
    printf("\n This Program is to check the Proximity of\n Entered number to the Defined Variable");
    printf("\n Enter the User Variable : ");
    scanf("%d", &UserVariable);
    while(RandVariable != UserVariable)
    {
        if(RandVariable<UserVariable)
            printf("\n Entered Number is Larger");
        else
            printf("\n Entered Number is Smaller");
    }

    printf("\n Congrats thats an perfecto Guess!");
}
