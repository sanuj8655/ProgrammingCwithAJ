#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main()
{
    int StoredNumber = 0;
    int UserVariable = 0;
    int RandVariable = 0;
    time_t t;
    printf("    \nWelcome! to\n\n Random Number generator game");
    srand((unsigned)time(&t));
    RandVariable = rand()%21;

    for(int count = 5; count >= 1 ; count--)
    {
        printf("\n\nYou have %d Tr%s  Left", count, count==1?"y":"ies");
        printf("\n\nEnter the User Variable : ");
        scanf("%d", &UserVariable);
        if(UserVariable>RandVariable)
        {
            printf("\n Entered Number is Larger");
        }
        else if(RandVariable>UserVariable)
        {
            printf("\n Entered Number is Smaller");
        }
         else if(RandVariable==UserVariable)
        {
            printf("\n Congrats");
            break;
        }
        else if (UserVariable>20 || UserVariable<0)
        {
            printf("\nPlease Enter Number from 0 to 20");
        }

    }


    printf("\n\n  Sorry your 5 Attempts are Over the Random Variable was: %d", RandVariable);
    return 0;
  }\
